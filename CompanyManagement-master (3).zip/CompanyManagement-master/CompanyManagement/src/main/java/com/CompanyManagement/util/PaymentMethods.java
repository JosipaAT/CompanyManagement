package com.CompanyManagement.util;

public enum PaymentMethods {

    CASH, CARD
}
