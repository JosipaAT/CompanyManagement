package com.CompanyManagement.util;

public enum PaymentStatus {

    CREATED,
    PAYED,
    ON_HOLD;

}
