package com.CompanyManagement.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
